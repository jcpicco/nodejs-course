let resultado = 1;
let i = 2;

while(i < 11){
    resultado = resultado*i;
    i++;
}

console.log(resultado)