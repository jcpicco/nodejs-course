let resultado = 1;

for (let i = 2 ; i < 11 ; i++){
    resultado = resultado*i;
}

console.log(resultado)