const miFamilia = new Set(["Andrea", "Pablo", "Lucía", "Josefina", "Juanma"]);
console.log(miFamilia);

miFamilia.add("Juanma");
console.log(miFamilia);

miFamilia.add("Javascript");
console.log(miFamilia);