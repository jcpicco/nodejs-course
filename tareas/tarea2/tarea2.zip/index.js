const libro_fav = {
    titulo: "Maximum Berserk",
    autor: "Kentaro Miura",
    fecha: new Date(2020, 10, 26),
    url: "https://www.panini.es/shp_esp_es/maximum-berserk-20-sbema020-es01.html"
}
const informacion = ["Juan Manuel Consigliere Picco", 23, true, new Date(1998, 11, 4), libro_fav]
console.log(informacion)